//
//  point.c
//  OpGL
//
//  Created by Cyril Steger on 30.10.2022.
//

#include "point.h"

