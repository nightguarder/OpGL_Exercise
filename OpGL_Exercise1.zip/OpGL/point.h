//
//  point.h
//  OpGL
//
//  Created by Cyril Steger on 30.10.2022.
//

class Point{
private:
    int x,y = 0;
public:
    Point(int x,int y){
        this->x = x;
        this->y = y;
    }
    int x,y;
};

